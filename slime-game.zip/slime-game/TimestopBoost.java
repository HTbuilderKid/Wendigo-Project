import greenfoot.*;

public class TimestopBoost extends PowerBoost {
    public TimestopBoost() {
        setImage("herz.png"); // placeholder
    }

    @Override
    public void applyEffect(Crab crab) {
        crab.timeStop(300); // 5 seconds freeze
    }
}
