import greenfoot.*;

public class LobsterMinion extends Actor {
    private GiantLobster boss;

    public LobsterMinion(GiantLobster boss) {
        this.boss = boss;
    }

    public void act() {
        turnAtEdge();
        randomTurn();
        move(3); // slower than normal lobster
        lookForCrab();
        checkBullet();
    }

    private void turnAtEdge() {
        if (isAtEdge()) {
            turn(17);
        }
    }

    private void randomTurn() {
        if (Greenfoot.getRandomNumber(100) > 90) {
            turn(Greenfoot.getRandomNumber(90) - 45);
        }
    }

    private void lookForCrab() {
        if (isTouching(Crab.class)) {
            removeTouching(Crab.class);
            Greenfoot.playSound("gameOver.wav");
            Greenfoot.setWorld(new GameOverWorld());
        }
    }

    private void checkBullet() {
        Bullet b = (Bullet) getOneIntersectingObject(Bullet.class);
        if (b != null) {
            getWorld().removeObject(b);

            // Damage the boss when a minion is destroyed
            if (boss != null) {
                boss.takeDamage(1);
            }

            // Play placeholder hit sound
            Greenfoot.playSound("au.wav");

            getWorld().removeObject(this);
        }
    }
}