import greenfoot.*;  

public class Bullet extends Actor
{
    private int speed = 6;

    public Bullet(int rotation)
    {
        setRotation(rotation);
        setImage(new GreenfootImage("bullet.png"));
    }

    public void act()
    {
        move(speed);
        checkEdge();
    }

    private void checkEdge()
    {
        if (isAtEdge()) {
            getWorld().removeObject(this);
        }
    }
}

