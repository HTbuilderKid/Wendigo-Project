import greenfoot.*;  

public class Player extends Actor
{
    private GreenfootImage[] idleFrames = new GreenfootImage[8];
    private GreenfootImage[] walkFrames = new GreenfootImage[8];
    private GreenfootImage[] runFrames  = new GreenfootImage[7];

    private int animationCounter = 0;  
    private int currentFrame = 0;      
    private int animationSpeed = 6;    

    private boolean facingRight = true;  // keeps track of direction

    public Player() {
        // Load idle frames
        for (int i = 0; i < idleFrames.length; i++) {
            idleFrames[i] = new GreenfootImage("playerAnimations/Idle/playerIdle" + (i+1) + ".png");
        }

        // Load walk frames
        for (int i = 0; i < walkFrames.length; i++) {
            walkFrames[i] = new GreenfootImage("playerAnimations/Walk/playerWalk" + (i+1) + ".png");
        }

        // Load run frames
        for (int i = 0; i < runFrames.length; i++) {
            runFrames[i] = new GreenfootImage("playerAnimations/Run/playerRun" + (i+1) + ".png");
        }

        setImage(idleFrames[0]); 
    }

    public void act() {
        handleMovement();
    }

    private void handleMovement() {
        boolean moving = false;
        boolean running = Greenfoot.isKeyDown("shift"); // check shift key

        if (Greenfoot.isKeyDown("right")) {
            facingRight = true;
            if (running) {
                setLocation(getX() + 5, getY()); // faster movement
                animate(runFrames);
            } else {
                setLocation(getX() + 3, getY());
                animate(walkFrames);
            }
            moving = true;
        }
        else if (Greenfoot.isKeyDown("left")) {
            facingRight = false;
            if (running) {
                setLocation(getX() - 5, getY());
                animate(runFrames);
            } else {
                setLocation(getX() - 3, getY());
                animate(walkFrames);
            }
            moving = true;
        }

        // Idle animation if not moving
        if (!moving) {
            animate(idleFrames);
        }
    }

    private void animate(GreenfootImage[] frames) {
        animationCounter++;
        if (animationCounter >= animationSpeed) {
            animationCounter = 0;
            currentFrame = (currentFrame + 1) % frames.length;

            GreenfootImage frame = new GreenfootImage(frames[currentFrame]);
            if (!facingRight) {
                frame.mirrorHorizontally();
            }
            setImage(frame);
        }
    }
}