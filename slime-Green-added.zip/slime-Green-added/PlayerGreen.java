import greenfoot.*;  

public class PlayerGreen extends Actor
{
    private GreenfootImage[] idleFrames = new GreenfootImage[8];
    private GreenfootImage[] walkFrames = new GreenfootImage[8];
    private GreenfootImage[] runFrames  = new GreenfootImage[7];
    private GreenfootImage[] jumpFrames = new GreenfootImage[10];
    
    private int animationCounter = 0;  
    private int currentFrame = 0;      
    private int animationSpeed = 6;    

    private boolean facingRight = true;  
    private boolean jumping = false;     
    private int jumpFrameIndex = 0;      
    private boolean attacking = false;   
    private int attackFrameIndex = 0;
    private boolean attacking2 = false;
    private int attack2FrameIndex = 0;
    private boolean attacking3 = false;
    private int attack3FrameIndex = 0;

    private int moveSpeed = 3; 
    private int runSpeed  = 5;  

    public PlayerGreen() {
        for (int i = 0; i < idleFrames.length; i++) {
            idleFrames[i] = new GreenfootImage("playerGreenAnimations/greenIdle/playerGreenIdle" + (i+1) + ".png");
        }

        for (int i = 0; i < walkFrames.length; i++) {
            walkFrames[i] = new GreenfootImage("playerGreenAnimations/greenWalk/playerGreenWalk" + (i+1) + ".png");
        }

        for (int i = 0; i < runFrames.length; i++) {
            runFrames[i] = new GreenfootImage("playerGreenAnimations/greenRun/playerGreenRun" + (i+1) + ".png");
        }

        for (int i = 0; i < jumpFrames.length; i++) {
            jumpFrames[i] = new GreenfootImage("playerGreenAnimations/greenJump/playerGreenJump" + (i+1) + ".png");
        }
        setImage(idleFrames[0]); 
    }

    public void act() {
        if (jumping) {
            handleJumpMovement();
            animateJump();
        } 
        else {
            handleMovement();
            if (Greenfoot.isKeyDown("space")) {
                startJump();
            }
        }
    }

    private void handleMovement() {
        boolean moving = false;
        boolean running = Greenfoot.isKeyDown("shift"); 

        if (Greenfoot.isKeyDown("right")) {
            facingRight = true;
            int speed = running ? runSpeed : moveSpeed;
            setLocation(getX() + speed, getY()); 
            animate(running ? runFrames : walkFrames);
            moving = true;
        }
        else if (Greenfoot.isKeyDown("left")) {
            facingRight = false;
            int speed = running ? runSpeed : moveSpeed;
            setLocation(getX() - speed, getY()); 
            animate(running ? runFrames : walkFrames);
            moving = true;
        }
        else if (Greenfoot.isKeyDown("up")) {
            setLocation(getX(), getY() - moveSpeed);
            animate(running ? runFrames : walkFrames);
            moving = true;
        }
        else if (Greenfoot.isKeyDown("down")) {
            setLocation(getX(), getY() + moveSpeed);
            animate(running ? runFrames : walkFrames);
            moving = true;
        }
        if (!moving) {
            animate(idleFrames);
        }
    }

    private void startJump() {
        jumping = true;
        jumpFrameIndex = 0;
        animationCounter = 0;
    }

    private void handleJumpMovement() {
        int speed = Greenfoot.isKeyDown("shift") ? runSpeed : moveSpeed;
        if (Greenfoot.isKeyDown("right")) {
            facingRight = true;
            setLocation(getX() + speed, getY());
        }
        else if (Greenfoot.isKeyDown("left")) {
            facingRight = false;
            setLocation(getX() - speed, getY());
        }
    }

    private void animateJump() {
        animationCounter++;
        if (animationCounter >= animationSpeed) {
            animationCounter = 0;
            if (jumpFrameIndex < jumpFrames.length) {
                GreenfootImage frame = new GreenfootImage(jumpFrames[jumpFrameIndex]);
                if (!facingRight) {
                    frame.mirrorHorizontally();
                }
                setImage(frame);
                jumpFrameIndex++;
            } else {
                jumping = false;
                currentFrame = 0;
                setImage(idleFrames[0]);
            }
        }
    }

    private void animate(GreenfootImage[] frames) {
        animationCounter++;
        if (animationCounter >= animationSpeed) {
            animationCounter = 0;
            currentFrame = (currentFrame + 1) % frames.length;

            GreenfootImage frame = new GreenfootImage(frames[currentFrame]);
            if (!facingRight) {
                frame.mirrorHorizontally();
            }
            setImage(frame);
        }
    }
}