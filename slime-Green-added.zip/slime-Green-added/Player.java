import greenfoot.*;  

public class Player extends Actor
{
    private GreenfootImage[] idleFrames = new GreenfootImage[8];
    private GreenfootImage[] walkFrames = new GreenfootImage[8];
    private GreenfootImage[] runFrames  = new GreenfootImage[7];
    private GreenfootImage[] jumpFrames = new GreenfootImage[10];
    private GreenfootImage[] attack1Frames = new GreenfootImage[4];
    private GreenfootImage[] attack2Frames = new GreenfootImage[4];
    private GreenfootImage[] attack3Frames = new GreenfootImage[5];
    
    private int animationCounter = 0;  
    private int currentFrame = 0;      
    private int animationSpeed = 6;    

    private boolean facingRight = true;  
    private boolean jumping = false;     
    private int jumpFrameIndex = 0;      
    private boolean attacking = false;   
    private int attackFrameIndex = 0;
    private boolean attacking2 = false;
    private int attack2FrameIndex = 0;
    private boolean attacking3 = false;
    private int attack3FrameIndex = 0;

    private int moveSpeed = 3; 
    private int runSpeed  = 5;  

    public Player() {
        for (int i = 0; i < idleFrames.length; i++) {
            idleFrames[i] = new GreenfootImage("playerAnimations/Idle/playerIdle" + (i+1) + ".png");
        }

        for (int i = 0; i < walkFrames.length; i++) {
            walkFrames[i] = new GreenfootImage("playerAnimations/Walk/playerWalk" + (i+1) + ".png");
        }

        for (int i = 0; i < runFrames.length; i++) {
            runFrames[i] = new GreenfootImage("playerAnimations/Run/playerRun" + (i+1) + ".png");
        }

        for (int i = 0; i < jumpFrames.length; i++) {
            jumpFrames[i] = new GreenfootImage("playerAnimations/Jump/playerJump" + (i+1) + ".png");
        }

        for (int i = 0; i < attack1Frames.length; i++) {
            attack1Frames[i] = new GreenfootImage("playerAnimations/Attack1/playerAttack" + (i+1) + ".png");
        }
        
        for (int i = 0; i < attack2Frames.length; i++) {
            attack2Frames[i] = new GreenfootImage("playerAnimations/Attack2/playerAttack2-" + (i+1) + ".png");
        }
        
        for (int i = 0; i < attack3Frames.length; i++) {
            attack3Frames[i] = new GreenfootImage("playerAnimations/Attack3/playerAttack3-" + (i+1) + ".png");
        }
        setImage(idleFrames[0]); 
    }

    public void act() {
        if (attacking) {
            animateAttack1(); 
        }
        else if (attacking2) {
            animateAttack2();
        }
        else if (attacking3) {
            animateAttack3();
        }
        else if (jumping) {
            handleJumpMovement();
            animateJump();
        } 
        else {
            handleMovement();
            if (Greenfoot.isKeyDown("space")) {
                startJump();
            }
            else if (Greenfoot.isKeyDown("e")) {  
                startAttack1();
            }
            else if (Greenfoot.isKeyDown("r")) {
                startAttack2();
            }
            else if (Greenfoot.isKeyDown("t")) {
                startAttack3();
            }
        }
    }

    private void startAttack1() {
        attacking = true;
        attackFrameIndex = 0;
        animationCounter = 0;
    }
    
    private void startAttack2() {
        attacking2 = true;
        attack2FrameIndex = 0;
        animationCounter = 0;
    }
    
    private void startAttack3() {
        attacking3 = true;
        attack3FrameIndex = 0;
        animationCounter = 0;
    }

    private void animateAttack1() {
        animationCounter++;
        if (animationCounter >= animationSpeed) {
            animationCounter = 0;

            if (attackFrameIndex < attack1Frames.length) {
                GreenfootImage frame = new GreenfootImage(attack1Frames[attackFrameIndex]);
                if (!facingRight) {
                    frame.mirrorHorizontally();
                }
                setImage(frame);
                attackFrameIndex++;
            } else {
                attacking = false; 
                currentFrame = 0;
                setImage(idleFrames[0]);
            }
        }
    }
    
    private void animateAttack2() {
        animationCounter++;
        if (animationCounter >= animationSpeed) {
            animationCounter = 0;
            if (attack2FrameIndex < attack2Frames.length) {
                GreenfootImage frame = new GreenfootImage(attack2Frames[attack2FrameIndex]);
                if (!facingRight) {
                    frame.mirrorHorizontally();
                }
                setImage(frame);
                attack2FrameIndex++;
            } else {
                attacking2 = false;
                currentFrame = 0;
                setImage(idleFrames[0]);
            }
        }
    }
    
    private void animateAttack3() {
        animationCounter++;
        if (animationCounter >= animationSpeed) {
            animationCounter = 0;
            if (attack3FrameIndex < attack3Frames.length) {
                GreenfootImage frame = new GreenfootImage(attack3Frames[attack3FrameIndex]);
                if (!facingRight) {
                    frame.mirrorHorizontally();
                }
                setImage(frame);
                attack3FrameIndex++;
            } else {
                attacking3 = false;
                currentFrame = 0;
                setImage(idleFrames[0]);
            }
        }
    }

    private void handleMovement() {
        boolean moving = false;
        boolean running = Greenfoot.isKeyDown("shift"); 

        if (Greenfoot.isKeyDown("right")) {
            facingRight = true;
            int speed = running ? runSpeed : moveSpeed;
            setLocation(getX() + speed, getY()); 
            animate(running ? runFrames : walkFrames);
            moving = true;
        }
        else if (Greenfoot.isKeyDown("left")) {
            facingRight = false;
            int speed = running ? runSpeed : moveSpeed;
            setLocation(getX() - speed, getY()); 
            animate(running ? runFrames : walkFrames);
            moving = true;
        }
        else if (Greenfoot.isKeyDown("up")) {
            setLocation(getX(), getY() - moveSpeed);
            animate(running ? runFrames : walkFrames);
            moving = true;
        }
        else if (Greenfoot.isKeyDown("down")) {
            setLocation(getX(), getY() + moveSpeed);
            animate(running ? runFrames : walkFrames);
            moving = true;
        }
        if (!moving) {
            animate(idleFrames);
        }
    }

    private void startJump() {
        jumping = true;
        jumpFrameIndex = 0;
        animationCounter = 0;
    }

    private void handleJumpMovement() {
        int speed = Greenfoot.isKeyDown("shift") ? runSpeed : moveSpeed;
        if (Greenfoot.isKeyDown("right")) {
            facingRight = true;
            setLocation(getX() + speed, getY());
        }
        else if (Greenfoot.isKeyDown("left")) {
            facingRight = false;
            setLocation(getX() - speed, getY());
        }
    }

    private void animateJump() {
        animationCounter++;
        if (animationCounter >= animationSpeed) {
            animationCounter = 0;
            if (jumpFrameIndex < jumpFrames.length) {
                GreenfootImage frame = new GreenfootImage(jumpFrames[jumpFrameIndex]);
                if (!facingRight) {
                    frame.mirrorHorizontally();
                }
                setImage(frame);
                jumpFrameIndex++;
            } else {
                jumping = false;
                currentFrame = 0;
                setImage(idleFrames[0]);
            }
        }
    }

    private void animate(GreenfootImage[] frames) {
        animationCounter++;
        if (animationCounter >= animationSpeed) {
            animationCounter = 0;
            currentFrame = (currentFrame + 1) % frames.length;

            GreenfootImage frame = new GreenfootImage(frames[currentFrame]);
            if (!facingRight) {
                frame.mirrorHorizontally();
            }
            setImage(frame);
        }
    }
}