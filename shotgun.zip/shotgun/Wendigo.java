import greenfoot.*;  

public class Wendigo extends Actor
{
    // Normal form
    private GreenfootImage[] walkImagesLeft = new GreenfootImage[6];
    private GreenfootImage[] walkImagesRight = new GreenfootImage[6];
    
    // Slime form
    private GreenfootImage[] slimeImagesLeft = new GreenfootImage[6];
    private GreenfootImage[] slimeImagesRight = new GreenfootImage[6];
    
    // Transformation frames
    private GreenfootImage[] transformFramesLeft = new GreenfootImage[2];
    private GreenfootImage[] transformFramesRight = new GreenfootImage[2];
    private int transformCounter = 0;       
    private int transformDelayCounter = 0;  
    private boolean transforming = false;

    private int currentFrame = 0;
    private int animationCounter = 0;  
    private boolean facingRight = false; // default left
    private boolean slimeForm = false;   // start in normal form

    public Wendigo() {
        // Load normal images
        for (int i = 0; i < walkImagesLeft.length; i++) {
            walkImagesLeft[i] = new GreenfootImage("wendigo" + (i+1) + ".png");
            walkImagesRight[i] = new GreenfootImage(walkImagesLeft[i]);
            walkImagesRight[i].mirrorHorizontally();
        }

        // Load slime images
        for (int i = 0; i < slimeImagesLeft.length; i++) {
            slimeImagesLeft[i] = new GreenfootImage("wendigoSlime" + (i+1) + ".png");
            slimeImagesRight[i] = new GreenfootImage(slimeImagesLeft[i]);
            slimeImagesRight[i].mirrorHorizontally();
        }

        // Load transformation frames (both directions)
        for (int i = 0; i < 2; i++) {
            transformFramesLeft[i] = new GreenfootImage("transformation" + (i+1) + ".png");
            transformFramesRight[i] = new GreenfootImage(transformFramesLeft[i]);
            transformFramesRight[i].mirrorHorizontally();
        }

        setImage(walkImagesLeft[0]); // start normal, facing left
    }

    public void act() {
        if (transforming) {
            playTransformAnimation();
        } else {
            checkTransform();
            moveControl();
        }
    }

    /** Press T to begin transformation sequence */
    private void checkTransform() {
        if (Greenfoot.isKeyDown("t")) {
            transforming = true;
            transformCounter = 0;
            transformDelayCounter = 0;
            currentFrame = 0;
            animationCounter = 0;
            Greenfoot.delay(10); // prevent holding T
        }
    }

    /** Plays transformation animation with delay (0.5s per frame) */
    private void playTransformAnimation() {
        int frameDuration = 10; // ~0.5s at 60fps

        if (transformCounter < 8) { // 2 frames * 4 cycles
            if (transformDelayCounter == 0) {
                if (facingRight) {
                    setImage(transformFramesRight[transformCounter % 2]);
                } else {
                    setImage(transformFramesLeft[transformCounter % 2]);
                }
            }

            transformDelayCounter++;

            if (transformDelayCounter >= frameDuration) {
                transformCounter++;
                transformDelayCounter = 0;
            }
        } else {
            // Done transforming → flip state
            slimeForm = !slimeForm;
            transforming = false;
            // Reset idle image depending on new form + direction
            if (slimeForm) {
                setImage(facingRight ? slimeImagesRight[0] : slimeImagesLeft[0]);
            } else {
                setImage(facingRight ? walkImagesRight[0] : walkImagesLeft[0]);
            }
        }
    }

    private void moveControl() {
        boolean moving = false;

        if (Greenfoot.isKeyDown("up")) {
            setLocation(getX(), getY() - 3);
            moving = true;
        }
        if (Greenfoot.isKeyDown("down")) {
            setLocation(getX(), getY() + 3);
            moving = true;
        }
        if (Greenfoot.isKeyDown("left")) {
            setLocation(getX() - 3, getY());
            moving = true;
            facingRight = false;
        }
        if (Greenfoot.isKeyDown("right")) {
            setLocation(getX() + 3, getY());
            moving = true;
            facingRight = true;
        }

        if (moving) {
            animateWalk();
        } else {
            // Idle frame depends on form + direction
            if (slimeForm) {
                setImage(facingRight ? slimeImagesRight[0] : slimeImagesLeft[0]);
            } else {
                setImage(facingRight ? walkImagesRight[0] : walkImagesLeft[0]);
            }
        }
    }

    private void animateWalk() {
        animationCounter++;
        if (animationCounter % 6 == 0) { 
            currentFrame = (currentFrame + 1) % 6;
            if (slimeForm) {
                setImage(facingRight ? slimeImagesRight[currentFrame] : slimeImagesLeft[currentFrame]);
            } else {
                setImage(facingRight ? walkImagesRight[currentFrame] : walkImagesLeft[currentFrame]);
            }
        }
    }
}