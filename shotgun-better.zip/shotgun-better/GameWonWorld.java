import greenfoot.*;  // (World, Actor, Greenfoot, GreenfootImage)

public class GameWonWorld extends World
{
    private int timer = 0;
    private final int showDuration = 400; 

    public GameWonWorld()
    {
        // same size as your CrabWorld
        super(1000, 800, 1);

        // set background image (put the file in your project’s images folder)
        //setBackground("blue.png");

        // draw text over background
        showText("Yoooo! You won the game!!!", getWidth() / 2, getHeight() / 2);
        showText("Get ready for the boss...", getWidth() / 2, getHeight() / 2 + 40);
    }

    public void act()
    {
        timer++;

        if (timer == 1) {
            Greenfoot.playSound("gameWon.wav"); // placeholder, add your sound later
        }
    }
}