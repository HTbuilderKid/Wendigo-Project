import greenfoot.*;  

public class Player extends Actor
{
    private GreenfootImage playerIdle;
    private GreenfootImage[] playerShoot;
    private GreenfootImage[] playerReload;
    private int frame;           
    private int animationDelay;  
    private int delayCount;
    private int ammo;           
    private int maxAmmo = 5;    
    private int shootCooldown = 20;
    private int shootTimer = 0;
    
    private enum State { IDLE, SHOOT, RELOAD }
    private State currentState = State.IDLE;
    
    public Player()
    {
        playerIdle = new GreenfootImage("playerAnimations/Idle/playerIdle.png");
        
        playerShoot = new GreenfootImage[5];
        for(int i = 0; i < 5; i++) {
            playerShoot[i] = new GreenfootImage("playerAnimations/Shoot/playerShoot" + (i+1) + ".png");
        }
        
        playerReload = new GreenfootImage[5];
        for(int i = 0; i < 5; i++) {
            playerReload[i] = new GreenfootImage("playerAnimations/Reload/playerReload" + (i+1) + ".png");
        }
        
        setImage(playerIdle);
        frame = 0;
        animationDelay = 5;  
        delayCount = 0;
        ammo = maxAmmo; 
    }
    
    public void act()
    {
        if (shootTimer > 0) {
            shootTimer--;
        }
        handleInput();
        animate();
        followMouse();
    }
    
    private void followMouse()
    {
        MouseInfo mouse = Greenfoot.getMouseInfo();
        if (mouse != null) {
            turnTowards(mouse.getX(), mouse.getY());
        }
    }
    
    private void handleInput()
    {
        if (Greenfoot.mousePressed(null) && currentState != State.RELOAD && ammo > 0 && shootTimer == 0) {   
            currentState = State.SHOOT;
            frame = 0;
            ammo--; 
            shootTimer = shootCooldown;
        }
        else if (Greenfoot.isKeyDown("r") && currentState != State.RELOAD) {  
            currentState = State.RELOAD;
            frame = 0;
        }
        else if (ammo == 0 && currentState != State.RELOAD) {
            currentState = State.RELOAD;
            frame = 0;
        }
        else if (currentState != State.SHOOT && currentState != State.RELOAD) {
            currentState = State.IDLE;
        }
    }
    
    private void animate()
    {
        delayCount++;
        if (delayCount < animationDelay) return;
        delayCount = 0;
        
        GreenfootImage currentFrame = null;
        
        switch(currentState) {
            case IDLE:
                currentFrame = new GreenfootImage(playerIdle);
                break;
                
            case SHOOT:
                currentFrame = new GreenfootImage(playerShoot[frame]);
                
                if (frame == 0) {
                    move(-35); // recoil
                    fireBullet(); // shoot em up
                }
                
                frame++;
                if (frame >= playerShoot.length) {
                    frame = 0;
                    currentState = State.IDLE;
                }
                break;
                
            case RELOAD:
                currentFrame = new GreenfootImage(playerReload[frame]);
                frame++;
                if (frame >= playerReload.length) {
                    frame = 0;
                    ammo = maxAmmo;  
                    currentState = State.IDLE;
                }
                break;
        }
        
        if (currentFrame != null) {
            setImage(currentFrame);
        }
    }
    
    private void fireBullet()
    {
        Bullet b = new Bullet(10); // bullet speed
        getWorld().addObject(b, getX(), getY());
        b.setRotation(getRotation()); // fire in current facing direction
    }
}